export const translations = {
  en: {
    // General
    luxeAuto: 'LuxeAuto',
    loading: 'Loading...',
    
    // Navigation
    home: 'Home',
    brands: 'Brands',
    explore: 'Explore',
    support: 'Support',
    contact: 'Contact',
    login: 'Login',
    register: 'Register',
    profile: 'Profile',
    logout: 'Logout',
    
    // Home Page
    welcomeHeading: 'Discover Your Dream Car',
    welcomeSubheading: 'Explore our premium selection of vehicles',
    exploreVehicles: 'Explore Vehicles',
    bookTestDrive: 'Book a Test Drive',
    featuredVehicles: 'Featured Vehicles',
    newArrivals: 'New Arrivals',
    topBrands: 'Top Brands',
    viewAll: 'View All',
    
    // Brands & Cars
    allBrands: 'All Brands',
    popularModels: 'Popular Models',
    specifications: 'Specifications',
    features: 'Features',
    viewIn360: 'View in 360°',
    engine: 'Engine',
    transmission: 'Transmission',
    fuelEfficiency: 'Fuel Efficiency',
    topSpeed: 'Top Speed',
    acceleration: 'Acceleration',
    
    // Auth
    loginHeading: 'Welcome Back',
    loginSubheading: 'Enter your credentials to access your account',
    email: 'Email',
    password: 'Password',
    confirmPassword: 'Confirm Password',
    forgotPassword: 'Forgot Password?',
    rememberMe: 'Remember Me',
    dontHaveAccount: 'Don\'t have an account?',
    alreadyHaveAccount: 'Already have an account?',
    createAccount: 'Create Account',
    
    // Support & Contact
    supportHeading: 'We\'re Here to Help',
    supportSubheading: 'Get assistance with your inquiries and issues',
    contactHeading: 'Get in Touch',
    contactSubheading: 'We\'d love to hear from you',
    firstName: 'First Name',
    lastName: 'Last Name',
    message: 'Message',
    phone: 'Phone',
    subject: 'Subject',
    sendMessage: 'Send Message',
    liveChatSupport: 'Live Chat Support',
    startChat: 'Start Chat',
    faq: 'Frequently Asked Questions',
    
    // Footer
    quickLinks: 'Quick Links',
    popularBrands: 'Popular Brands',
    contactUs: 'Contact Us',
    footerTagline: 'Experience luxury and performance with our premium automotive showroom.',
    support24_7: '24/7 Customer Support',
    getInTouch: 'Get in Touch',
    allRightsReserved: 'All Rights Reserved',
    
    // Misc
    selectLanguage: 'Select Language',
    viewDetails: 'View Details',
    compareModels: 'Compare Models',
    filters: 'Filters',
    sort: 'Sort',
    search: 'Search',
    priceRange: 'Price Range',
    bodyType: 'Body Type',
  },
  
  es: {
    // General
    luxeAuto: 'LuxeAuto',
    loading: 'Cargando...',
    
    // Navigation
    home: 'Inicio',
    brands: 'Marcas',
    explore: 'Explorar',
    support: 'Soporte',
    contact: 'Contacto',
    login: 'Iniciar Sesión',
    register: 'Registrarse',
    profile: 'Perfil',
    logout: 'Cerrar Sesión',
    
    // Home Page
    welcomeHeading: 'Descubre Tu Auto Soñado',
    welcomeSubheading: 'Explora nuestra selección premium de vehículos',
    exploreVehicles: 'Explorar Vehículos',
    bookTestDrive: 'Reservar Prueba de Manejo',
    featuredVehicles: 'Vehículos Destacados',
    newArrivals: 'Nuevas Llegadas',
    topBrands: 'Mejores Marcas',
    viewAll: 'Ver Todo',
    
    // Brands & Cars
    allBrands: 'Todas las Marcas',
    popularModels: 'Modelos Populares',
    specifications: 'Especificaciones',
    features: 'Características',
    viewIn360: 'Ver en 360°',
    engine: 'Motor',
    transmission: 'Transmisión',
    fuelEfficiency: 'Eficiencia de Combustible',
    topSpeed: 'Velocidad Máxima',
    acceleration: 'Aceleración',
    
    // Auth
    loginHeading: 'Bienvenido de Nuevo',
    loginSubheading: 'Ingresa tus credenciales para acceder a tu cuenta',
    email: 'Correo Electrónico',
    password: 'Contraseña',
    confirmPassword: 'Confirmar Contraseña',
    forgotPassword: '¿Olvidaste tu Contraseña?',
    rememberMe: 'Recordarme',
    dontHaveAccount: '¿No tienes una cuenta?',
    alreadyHaveAccount: '¿Ya tienes una cuenta?',
    createAccount: 'Crear Cuenta',
    
    // Support & Contact
    supportHeading: 'Estamos Aquí para Ayudar',
    supportSubheading: 'Obtén asistencia con tus consultas y problemas',
    contactHeading: 'Ponte en Contacto',
    contactSubheading: 'Nos encantaría saber de ti',
    firstName: 'Nombre',
    lastName: 'Apellido',
    message: 'Mensaje',
    phone: 'Teléfono',
    subject: 'Asunto',
    sendMessage: 'Enviar Mensaje',
    liveChatSupport: 'Soporte por Chat en Vivo',
    startChat: 'Iniciar Chat',
    faq: 'Preguntas Frecuentes',
    
    // Footer
    quickLinks: 'Enlaces Rápidos',
    popularBrands: 'Marcas Populares',
    contactUs: 'Contáctanos',
    footerTagline: 'Experimenta lujo y rendimiento con nuestro concesionario premium.',
    support24_7: 'Soporte al Cliente 24/7',
    getInTouch: 'Contactar',
    allRightsReserved: 'Todos los Derechos Reservados',
    
    // Misc
    selectLanguage: 'Seleccionar Idioma',
    viewDetails: 'Ver Detalles',
    compareModels: 'Comparar Modelos',
    filters: 'Filtros',
    sort: 'Ordenar',
    search: 'Buscar',
    priceRange: 'Rango de Precio',
    bodyType: 'Tipo de Carrocería',
  },
  
  // Add other languages with the same structure
  fr: {
    // General (just a subset for the example)
    luxeAuto: 'LuxeAuto',
    loading: 'Chargement...',
    home: 'Accueil',
    brands: 'Marques',
    explore: 'Explorer',
    support: 'Support',
    contact: 'Contact',
    login: 'Connexion',
    register: 'S\'inscrire',
    profile: 'Profil',
    logout: 'Déconnexion',
    welcomeHeading: 'Découvrez Votre Voiture de Rêve',
    welcomeSubheading: 'Explorez notre sélection de véhicules haut de gamme',
    // Other translations would follow...
  },
  
  de: {
    // General (just a subset for the example)
    luxeAuto: 'LuxeAuto',
    loading: 'Wird geladen...',
    home: 'Startseite',
    brands: 'Marken',
    explore: 'Entdecken',
    support: 'Unterstützung',
    contact: 'Kontakt',
    login: 'Anmelden',
    register: 'Registrieren',
    profile: 'Profil',
    logout: 'Abmelden',
    // Other translations would follow...
  },
  
  ja: {
    // General (just a subset for the example)
    luxeAuto: 'ラックスオート',
    loading: '読み込み中...',
    home: 'ホーム',
    brands: 'ブランド',
    explore: '探索',
    support: 'サポート',
    contact: 'お問い合わせ',
    login: 'ログイン',
    register: '登録',
    profile: 'プロフィール',
    logout: 'ログアウト',
    // Other translations would follow...
  },
  
  zh: {
    // General (just a subset for the example)
    luxeAuto: '豪华汽车',
    loading: '加载中...',
    home: '首页',
    brands: '品牌',
    explore: '探索',
    support: '支持',
    contact: '联系',
    login: '登录',
    register: '注册',
    profile: '个人资料',
    logout: '登出',
    // Other translations would follow...
  }
};