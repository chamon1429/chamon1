export interface Car {
  id: string;
  brandId: string;
  model: string;
  year: number;
  price: number;
  description: string;
  images: string[];
  view360: string; // URL to 360 view resource
  colors: string[];
  specifications: {
    engine: string;
    horsepower: number;
    torque: string;
    transmission: string;
    drivetrain: string;
    fuelEfficiency: string;
    acceleration: string;
    topSpeed: string;
  };
  features: string[];
  bodyType: string;
  seatingCapacity: number;
  fuelType: string;
}

export const cars: Car[] = [
  // Toyota Cars
  {
    id: 'toyota-camry',
    brandId: 'toyota',
    model: 'Camry',
    year: 2023,
    price: 26420,
    description: 'The Toyota Camry is a series of mid-size cars manufactured by Toyota since 1982. The Camry has been a popular choice for families and commuters for decades.',
    images: [
      'https://images.pexels.com/photos/170811/pexels-photo-170811.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      'https://images.pexels.com/photos/4674337/pexels-photo-4674337.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      'https://images.pexels.com/photos/4440543/pexels-photo-4440543.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    ],
    view360: 'https://example.com/360/toyota-camry', // This would be replaced with an actual 360 view URL
    colors: ['Midnight Black', 'Celestial Silver', 'Supersonic Red', 'Blueprint', 'Wind Chill Pearl'],
    specifications: {
      engine: '2.5L 4-Cylinder',
      horsepower: 203,
      torque: '184 lb-ft',
      transmission: '8-Speed Automatic',
      drivetrain: 'Front-Wheel Drive',
      fuelEfficiency: '28 city / 39 highway mpg',
      acceleration: '0-60 mph in 7.5 seconds',
      topSpeed: '135 mph'
    },
    features: [
      'Toyota Safety Sense 2.5+',
      '9-inch touchscreen infotainment system',
      'Apple CarPlay and Android Auto',
      'Dual-zone automatic climate control',
      'Power driver\'s seat',
      'LED headlights',
      'Keyless entry and ignition'
    ],
    bodyType: 'Sedan',
    seatingCapacity: 5,
    fuelType: 'Gasoline'
  },
  {
    id: 'toyota-corolla',
    brandId: 'toyota',
    model: 'Corolla',
    year: 2023,
    price: 21550,
    description: 'The Toyota Corolla is a line of compact cars manufactured by Toyota. Introduced in 1966, the Corolla has become one of the best-selling cars worldwide.',
    images: [
      'https://images.pexels.com/photos/13975360/pexels-photo-13975360.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      'https://images.pexels.com/photos/13975370/pexels-photo-13975370.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      'https://images.pexels.com/photos/17644402/pexels-photo-17644402/free-photo-of-toyota-corolla-parked-on-road.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    ],
    view360: 'https://example.com/360/toyota-corolla',
    colors: ['Classic Silver Metallic', 'Black Sand Pearl', 'Barcelona Red Metallic', 'Blue Crush Metallic', 'Blizzard Pearl'],
    specifications: {
      engine: '1.8L 4-Cylinder',
      horsepower: 139,
      torque: '126 lb-ft',
      transmission: 'Continuously Variable Transmission (CVT)',
      drivetrain: 'Front-Wheel Drive',
      fuelEfficiency: '31 city / 40 highway mpg',
      acceleration: '0-60 mph in 8.5 seconds',
      topSpeed: '115 mph'
    },
    features: [
      'Toyota Safety Sense 2.0',
      '8-inch touchscreen display',
      'Apple CarPlay and Android Auto',
      'Wi-Fi Connect',
      'Automatic climate control',
      'LED headlights',
      'Smart Key System with Push Button Start'
    ],
    bodyType: 'Sedan',
    seatingCapacity: 5,
    fuelType: 'Gasoline'
  },
  
  // Honda Cars
  {
    id: 'honda-civic',
    brandId: 'honda',
    model: 'Civic',
    year: 2023,
    price: 23950,
    description: 'The Honda Civic is a line of cars manufactured by Honda. Introduced in 1972 as a subcompact, the Civic has gone through several generational changes, becoming both larger and more upscale.',
    images: [
      'https://images.pexels.com/photos/13467147/pexels-photo-13467147.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      'https://images.pexels.com/photos/18151723/pexels-photo-18151723/free-photo-of-red-honda-civic-type-r-on-a-street.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      'https://images.pexels.com/photos/13467154/pexels-photo-13467154.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    ],
    view360: 'https://example.com/360/honda-civic',
    colors: ['Platinum White Pearl', 'Crystal Black Pearl', 'Sonic Gray Pearl', 'Rallye Red', 'Aegean Blue Metallic'],
    specifications: {
      engine: '2.0L 4-Cylinder',
      horsepower: 158,
      torque: '138 lb-ft',
      transmission: 'Continuously Variable Transmission (CVT)',
      drivetrain: 'Front-Wheel Drive',
      fuelEfficiency: '31 city / 40 highway mpg',
      acceleration: '0-60 mph in 7.9 seconds',
      topSpeed: '125 mph'
    },
    features: [
      'Honda Sensing Suite',
      '7-inch touchscreen display',
      'Apple CarPlay and Android Auto',
      'Automatic climate control',
      'Push button start',
      'LED headlights',
      'Multi-angle rearview camera'
    ],
    bodyType: 'Sedan',
    seatingCapacity: 5,
    fuelType: 'Gasoline'
  },
  
  // BMW Cars
  {
    id: 'bmw-3-series',
    brandId: 'bmw',
    model: '3 Series',
    year: 2023,
    price: 43300,
    description: 'The BMW 3 Series is a line of compact executive cars manufactured by the German automaker BMW since May 1975. It is the successor to the 02 Series and has been produced in seven generations.',
    images: [
      'https://images.pexels.com/photos/892522/pexels-photo-892522.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      'https://images.pexels.com/photos/951318/pexels-photo-951318.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      'https://images.pexels.com/photos/707046/pexels-photo-707046.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    ],
    view360: 'https://example.com/360/bmw-3-series',
    colors: ['Alpine White', 'Jet Black', 'Mineral Gray Metallic', 'Sunset Orange Metallic', 'Portimao Blue Metallic'],
    specifications: {
      engine: '2.0L TwinPower Turbo 4-Cylinder',
      horsepower: 255,
      torque: '295 lb-ft',
      transmission: '8-Speed Automatic',
      drivetrain: 'Rear-Wheel Drive',
      fuelEfficiency: '26 city / 36 highway mpg',
      acceleration: '0-60 mph in 5.6 seconds',
      topSpeed: '155 mph'
    },
    features: [
      'Live Cockpit Professional with navigation',
      '10.25-inch touchscreen display',
      'Apple CarPlay and Android Auto',
      'Comfort Access keyless entry',
      'Automatic 3-zone climate control',
      'LED headlights',
      'Harman Kardon surround sound system'
    ],
    bodyType: 'Sedan',
    seatingCapacity: 5,
    fuelType: 'Gasoline'
  },
  
  // Add more cars for different brands...
  {
    id: 'mercedes-c-class',
    brandId: 'mercedes',
    model: 'C-Class',
    year: 2023,
    price: 46000,
    description: 'The Mercedes-Benz C-Class is a line of compact executive cars produced by Mercedes-Benz. Introduced in 1993 as a replacement for the 190 (W201) range, the C-Class was the smallest model in the marque\'s line-up until the W168 A-Class arrived in 1997.',
    images: [
      'https://images.pexels.com/photos/8862941/pexels-photo-8862941.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      'https://images.pexels.com/photos/1104768/pexels-photo-1104768.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      'https://images.pexels.com/photos/136872/pexels-photo-136872.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    ],
    view360: 'https://example.com/360/mercedes-c-class',
    colors: ['Polar White', 'Obsidian Black Metallic', 'Mojave Silver Metallic', 'Selenite Grey Metallic', 'Brilliant Blue Metallic'],
    specifications: {
      engine: '2.0L Turbocharged 4-Cylinder',
      horsepower: 255,
      torque: '295 lb-ft',
      transmission: '9-Speed Automatic',
      drivetrain: 'Rear-Wheel Drive',
      fuelEfficiency: '25 city / 35 highway mpg',
      acceleration: '0-60 mph in 5.9 seconds',
      topSpeed: '155 mph'
    },
    features: [
      'MBUX infotainment system',
      '11.9-inch central touchscreen',
      '12.3-inch digital instrument cluster',
      'Burmester 3D surround sound system',
      'Heated front seats',
      'LED headlights',
      'Keyless-Go'
    ],
    bodyType: 'Sedan',
    seatingCapacity: 5,
    fuelType: 'Gasoline'
  }
];

export const getCarById = (id: string): Car | undefined => {
  return cars.find(car => car.id === id);
};

export const getCarsByBrand = (brandId: string): Car[] => {
  return cars.filter(car => car.brandId === brandId);
};

export const getAllCars = (): Car[] => {
  return cars;
};