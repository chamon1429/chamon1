export interface Brand {
  id: string;
  name: string;
  logo: string;
  description: string;
  country: string;
  foundedYear: number;
  models: string[]; // References to car IDs
}

export const brands: Brand[] = [
  {
    id: 'toyota',
    name: 'Toyota',
    logo: 'https://www.pexels.com/photo/close-up-shot-of-toyota-logo-on-a-black-car-11769197/',
    description: 'Toyota Motor Corporation is a Japanese multinational automotive manufacturer headquartered in Toyota City, Japan. It was founded by Kiichiro Toyoda and incorporated on August 28, 1937.',
    country: 'Japan',
    foundedYear: 1937,
    models: ['toyota-camry', 'toyota-corolla', 'toyota-rav4', 'toyota-highlander', 'toyota-tacoma']
  },
  {
    id: 'honda',
    name: 'Honda',
    logo: 'https://www.pexels.com/photo/honda-logo-8980459/',
    description: 'Honda Motor Co., Ltd. is a Japanese public multinational conglomerate manufacturer of automobiles, motorcycles, and power equipment, headquartered in Tokyo, Japan.',
    country: 'Japan',
    foundedYear: 1948,
    models: ['honda-civic', 'honda-accord', 'honda-cr-v', 'honda-pilot', 'honda-ridgeline']
  },
  {
    id: 'lexus',
    name: 'Lexus',
    logo: 'https://www.pexels.com/photo/lexus-logo-on-a-car-5240772/',
    description: 'Lexus is the luxury vehicle division of the Japanese automaker Toyota. The Lexus brand is marketed in more than 70 countries and territories worldwide and is Japan\'s largest-selling make of premium cars.',
    country: 'Japan',
    foundedYear: 1989,
    models: ['lexus-es', 'lexus-rx', 'lexus-ls', 'lexus-nx', 'lexus-is']
  },
  {
    id: 'bmw',
    name: 'BMW',
    logo: 'https://www.pexels.com/photo/bmw-car-logo-1149137/',
    description: 'Bayerische Motoren Werke AG, commonly referred to as BMW, is a German multinational manufacturer of luxury vehicles and motorcycles headquartered in Munich, Bavaria, Germany.',
    country: 'Germany',
    foundedYear: 1916,
    models: ['bmw-3-series', 'bmw-5-series', 'bmw-x5', 'bmw-7-series', 'bmw-i8']
  },
  {
    id: 'mercedes',
    name: 'Mercedes-Benz',
    logo: 'https://www.pexels.com/photo/silver-mercedes-benz-vehicle-on-road-120049/',
    description: 'Mercedes-Benz, commonly referred to as Mercedes, is a German luxury and commercial vehicle automotive brand established in 1926.',
    country: 'Germany',
    foundedYear: 1926,
    models: ['mercedes-c-class', 'mercedes-e-class', 'mercedes-s-class', 'mercedes-gle', 'mercedes-gls']
  },
  {
    id: 'audi',
    name: 'Audi',
    logo: 'https://www.pexels.com/photo/audi-parked-near-trees-1687147/',
    description: 'Audi AG is a German automotive manufacturer of luxury vehicles headquartered in Ingolstadt, Bavaria, Germany.',
    country: 'Germany',
    foundedYear: 1909,
    models: ['audi-a4', 'audi-a6', 'audi-q5', 'audi-q7', 'audi-r8']
  },
  {
    id: 'ford',
    name: 'Ford',
    logo: 'https://www.pexels.com/photo/ford-mustang-car-7194393/',
    description: 'Ford Motor Company is an American multinational automobile manufacturer headquartered in Dearborn, Michigan, United States.',
    country: 'USA',
    foundedYear: 1903,
    models: ['ford-f-150', 'ford-mustang', 'ford-explorer', 'ford-escape', 'ford-focus']
  },
  {
    id: 'chevrolet',
    name: 'Chevrolet',
    logo: 'https://www.pexels.com/photo/chevrolet-car-automobile-chrome-53435/',
    description: 'Chevrolet, colloquially referred to as Chevy, is an American automobile division of the American manufacturer General Motors.',
    country: 'USA',
    foundedYear: 1911,
    models: ['chevrolet-silverado', 'chevrolet-camaro', 'chevrolet-corvette', 'chevrolet-tahoe', 'chevrolet-malibu']
  }
];

export const getBrandById = (id: string): Brand | undefined => {
  return brands.find(brand => brand.id === id);
};

export const getAllBrands = (): Brand[] => {
  return brands;
};