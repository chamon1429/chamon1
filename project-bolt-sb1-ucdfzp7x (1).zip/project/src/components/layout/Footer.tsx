import { Link } from 'react-router-dom';
import { MapPin, Phone, Mail, Facebook, Instagram, Twitter, Youtube } from 'lucide-react';
import { useLanguage } from '../../contexts/LanguageContext';

const Footer = () => {
  const { t } = useLanguage();
  
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-gray-900 text-white">
      {/* Main Footer */}
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Company Info */}
          <div>
            <h3 className="text-xl font-bold mb-4">
              {t('luxeAuto')}
              <span className="text-red-500">.</span>
            </h3>
            <p className="text-gray-400 mb-4">
              {t('footerTagline')}
            </p>
            <div className="flex space-x-4">
              <a href="https://facebook.com" className="text-gray-400 hover:text-white transition-colors">
                <Facebook className="h-5 w-5" />
              </a>
              <a href="https://www.instagram.com/its_chandu._.14?igsh=YWczZ3MxMXdmeGRw" className="text-gray-400 hover:text-white transition-colors">
                <Instagram className="h-5 w-5" />
              </a>
              <a href="https://twitter.com" className="text-gray-400 hover:text-white transition-colors">
                <Twitter className="h-5 w-5" />
              </a>
              <a href="https://youtube.com" className="text-gray-400 hover:text-white transition-colors">
                <Youtube className="h-5 w-5" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-semibold mb-4">{t('quickLinks')}</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/" className="text-gray-400 hover:text-white transition-colors">
                  {t('home')}
                </Link>
              </li>
              <li>
                <Link to="/brands" className="text-gray-400 hover:text-white transition-colors">
                  {t('brands')}
                </Link>
              </li>
              <li>
                <Link to="/support" className="text-gray-400 hover:text-white transition-colors">
                  {t('support')}
                </Link>
              </li>
              <li>
                <Link to="/contact" className="text-gray-400 hover:text-white transition-colors">
                  {t('contact')}
                </Link>
              </li>
              <li>
                <Link to="/login" className="text-gray-400 hover:text-white transition-colors">
                  {t('login')}
                </Link>
              </li>
            </ul>
          </div>

          {/* Popular Brands */}
          <div>
            <h3 className="text-lg font-semibold mb-4">{t('popularBrands')}</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/brands/toyota" className="text-gray-400 hover:text-white transition-colors">
                  Toyota
                </Link>
              </li>
              <li>
                <Link to="/brands/honda" className="text-gray-400 hover:text-white transition-colors">
                  Honda
                </Link>
              </li>
              <li>
                <Link to="/brands/lexus" className="text-gray-400 hover:text-white transition-colors">
                  Lexus
                </Link>
              </li>
              <li>
                <Link to="/brands/bmw" className="text-gray-400 hover:text-white transition-colors">
                  BMW
                </Link>
              </li>
              <li>
                <Link to="/brands/mercedes" className="text-gray-400 hover:text-white transition-colors">
                  Mercedes-Benz
                </Link>
              </li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h3 className="text-lg font-semibold mb-4">{t('contactUs')}</h3>
            <ul className="space-y-4">
              <li className="flex items-start">
                <MapPin className="h-5 w-5 text-red-500 mr-2 mt-0.5" />
                <span className="text-gray-400">
                  123 Luxury Lane, <br />
                  Automotive City, AC 12345
                </span>
              </li>
              <li className="flex items-center">
                <Phone className="h-5 w-5 text-red-500 mr-2" />
                <span className="text-gray-400">+91 9361921485</span>
              </li>
              <li className="flex items-center">
                <Mail className="h-5 w-5 text-red-500 mr-2" />
                <a href="mailto:info@luxeauto.com" className="text-gray-400 hover:text-white transition-colors">
                  chamon1429@gmail.com
                </a>
              </li>
            </ul>
          </div>
        </div>
      </div>
      
      {/* 24/7 Support Banner */}
      <div className="bg-blue-900 py-4">
        <div className="container mx-auto px-4 flex flex-col md:flex-row justify-between items-center">
          <div className="flex items-center mb-4 md:mb-0">
            <Phone className="h-5 w-5 text-red-400 mr-2" />
            <span>{t('support24_7')}: <strong>105-5042-2004</strong></span>
          </div>
          <Link 
            to="/contact" 
            className="bg-red-600 hover:bg-red-700 text-white px-6 py-2 rounded-md transition-colors"
          >
            {t('getInTouch')}
          </Link>
        </div>
      </div>
      
      {/* Copyright */}
      <div className="bg-gray-950 py-4">
        <div className="container mx-auto px-4 text-center text-gray-500 text-sm">
          <p>
            &copy; {currentYear} chandu. {t('allRightsReserved')}
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;