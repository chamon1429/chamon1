import { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, ChevronDown, Globe, User } from 'lucide-react';
import { useLanguage } from '../../contexts/LanguageContext';
import { useAuth } from '../../contexts/AuthContext';
import LanguageSelector from '../ui/LanguageSelector';

const Header = () => {
  const { t } = useLanguage();
  const { isAuthenticated, user, logout } = useAuth();
  const [isOpen, setIsOpen] = useState(false);
  const [showLanguageMenu, setShowLanguageMenu] = useState(false);
  const [showUserMenu, setShowUserMenu] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const location = useLocation();

  // Close mobile menu when route changes
  useEffect(() => {
    setIsOpen(false);
  }, [location]);

  // Handle scroll events for header styling
  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 10) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const toggleMenu = () => setIsOpen(!isOpen);
  const toggleLanguageMenu = () => {
    setShowLanguageMenu(!showLanguageMenu);
    setShowUserMenu(false);
  };
  
  const toggleUserMenu = () => {
    setShowUserMenu(!showUserMenu);
    setShowLanguageMenu(false);
  };

  return (
    <header 
      className={`sticky top-0 z-50 w-full transition-all duration-300 ${
        isScrolled 
          ? 'bg-white bg-opacity-90 backdrop-blur-sm shadow-md' 
          : 'bg-transparent'
      }`}
    >
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between py-4">
          {/* Logo */}
          <Link to="/" className="flex items-center">
            <span className="text-2xl font-bold text-blue-900">
              {t('luxeAuto')}
              <span className="text-red-600">.</span>
            </span>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <Link to="/" className="text-gray-800 hover:text-blue-700 font-medium">
              {t('home')}
            </Link>
            <Link to="/brands" className="text-gray-800 hover:text-blue-700 font-medium">
              {t('brands')}
            </Link>
            <div className="relative group">
              <button 
                className="flex items-center text-gray-800 hover:text-blue-700 font-medium"
                onClick={() => {}}
              >
                {t('explore')} <ChevronDown className="ml-1 h-4 w-4" />
              </button>
              <div className="absolute left-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 hidden group-hover:block">
                <Link to="/brands/toyota" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                  Toyota
                </Link>
                <Link to="/brands/honda" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                  Honda
                </Link>
                <Link to="/brands/lexus" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                  Lexus
                </Link>
                <Link to="/brands/bmw" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                  BMW
                </Link>
              </div>
            </div>
            <Link to="/support" className="text-gray-800 hover:text-blue-700 font-medium">
              {t('support')}
            </Link>
            <Link to="/contact" className="text-gray-800 hover:text-blue-700 font-medium">
              {t('contact')}
            </Link>
          </nav>

          {/* Language and User Menus */}
          <div className="hidden md:flex items-center space-x-4">
            {/* Language Menu */}
            <div className="relative">
              <button 
                className="flex items-center text-gray-800 hover:text-blue-700"
                onClick={toggleLanguageMenu}
              >
                <Globe className="h-5 w-5" />
              </button>
              {showLanguageMenu && (
                <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 z-10">
                  <LanguageSelector onClose={() => setShowLanguageMenu(false)} />
                </div>
              )}
            </div>

            {/* Auth Buttons / User Menu */}
            {isAuthenticated ? (
              <div className="relative">
                <button 
                  className="flex items-center text-gray-800 hover:text-blue-700"
                  onClick={toggleUserMenu}
                >
                  <User className="h-5 w-5" />
                  <span className="ml-2">{user?.name}</span>
                </button>
                {showUserMenu && (
                  <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 z-10">
                    <Link to="/profile" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                      {t('profile')}
                    </Link>
                    <button 
                      onClick={logout}
                      className="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                    >
                      {t('logout')}
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <Link 
                to="/login" 
                className="bg-blue-800 hover:bg-blue-900 text-white px-6 py-2 rounded-md font-medium transition-colors"
              >
                {t('login')}
              </Link>
            )}
          </div>

          {/* Mobile Menu Button */}
          <button className="md:hidden" onClick={toggleMenu}>
            {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>

        {/* Mobile Menu */}
        {isOpen && (
          <div className="md:hidden py-4 border-t border-gray-200">
            <nav className="flex flex-col space-y-4">
              <Link to="/" className="text-gray-800 hover:text-blue-700 font-medium">
                {t('home')}
              </Link>
              <Link to="/brands" className="text-gray-800 hover:text-blue-700 font-medium">
                {t('brands')}
              </Link>
              <div>
                <button 
                  className="flex items-center text-gray-800 hover:text-blue-700 font-medium"
                  onClick={() => {}}
                >
                  {t('explore')} <ChevronDown className="ml-1 h-4 w-4" />
                </button>
                <div className="pl-4 mt-2 space-y-2">
                  <Link to="/brands/toyota" className="block text-gray-700 hover:text-blue-700">
                    Toyota
                  </Link>
                  <Link to="/brands/honda" className="block text-gray-700 hover:text-blue-700">
                    Honda
                  </Link>
                  <Link to="/brands/lexus" className="block text-gray-700 hover:text-blue-700">
                    Lexus
                  </Link>
                  <Link to="/brands/bmw" className="block text-gray-700 hover:text-blue-700">
                    BMW
                  </Link>
                </div>
              </div>
              <Link to="/support" className="text-gray-800 hover:text-blue-700 font-medium">
                {t('support')}
              </Link>
              <Link to="/contact" className="text-gray-800 hover:text-blue-700 font-medium">
                {t('contact')}
              </Link>
              
              {/* Mobile Language Selector */}
              <div className="pt-2 border-t border-gray-200">
                <p className="text-sm text-gray-500 mb-2">{t('selectLanguage')}</p>
                <LanguageSelector onClose={() => {}} />
              </div>
              
              {/* Mobile Auth */}
              <div className="pt-2 border-t border-gray-200">
                {isAuthenticated ? (
                  <>
                    <Link to="/profile" className="block text-gray-800 hover:text-blue-700 font-medium">
                      {t('profile')}
                    </Link>
                    <button 
                      onClick={logout}
                      className="text-gray-800 hover:text-blue-700 font-medium"
                    >
                      {t('logout')}
                    </button>
                  </>
                ) : (
                  <div className="flex flex-col space-y-2">
                    <Link 
                      to="/login" 
                      className="bg-blue-800 hover:bg-blue-900 text-white px-6 py-2 rounded-md font-medium transition-colors text-center"
                    >
                      {t('login')}
                    </Link>
                    <Link 
                      to="/register" 
                      className="border border-blue-800 text-blue-800 hover:bg-blue-50 px-6 py-2 rounded-md font-medium transition-colors text-center"
                    >
                      {t('register')}
                    </Link>
                  </div>
                )}
              </div>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;