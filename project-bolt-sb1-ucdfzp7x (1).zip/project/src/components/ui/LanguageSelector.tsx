import { useLanguage } from '../../contexts/LanguageContext';

type Language = {
  code: 'en' | 'es' | 'fr' | 'de' | 'ja' | 'zh';
  name: string;
  flag: string;
};

const languages: Language[] = [
  { code: 'en', name: 'English', flag: '🇺🇸' },
  { code: 'es', name: 'Español', flag: '🇪🇸' },
  { code: 'fr', name: 'Français', flag: '🇫🇷' },
  { code: 'de', name: 'Deutsch', flag: '🇩🇪' },
  { code: 'ja', name: '日本語', flag: '🇯🇵' },
  { code: 'zh', name: '中文', flag: '🇨🇳' },
];

interface LanguageSelectorProps {
  onClose: () => void;
}

const LanguageSelector: React.FC<LanguageSelectorProps> = ({ onClose }) => {
  const { language, setLanguage } = useLanguage();

  const handleLanguageChange = (langCode: 'en' | 'es' | 'fr' | 'de' | 'ja' | 'zh') => {
    setLanguage(langCode);
    onClose();
  };

  return (
    <div className="p-2">
      {languages.map((lang) => (
        <button
          key={lang.code}
          onClick={() => handleLanguageChange(lang.code)}
          className={`w-full text-left px-4 py-2 text-sm rounded-md flex items-center ${
            language === lang.code
              ? 'bg-blue-100 text-blue-800'
              : 'text-gray-700 hover:bg-gray-100'
          }`}
        >
          <span className="mr-2">{lang.flag}</span>
          <span>{lang.name}</span>
        </button>
      ))}
    </div>
  );
};

export default LanguageSelector;