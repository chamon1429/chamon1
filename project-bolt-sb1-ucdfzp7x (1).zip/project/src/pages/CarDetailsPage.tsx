import { useState, useEffect, useRef } from 'react';
import { useParams, useSearchParams, Link } from 'react-router-dom';
import { useLanguage } from '../contexts/LanguageContext';
import { getCarById, Car } from '../data/cars';
import { getBrandById } from '../data/brands';
import { ChevronLeft, ChevronRight, RotateCw, Calendar, Gauge, Fuel, Settings, User, CheckCircle } from 'lucide-react';

// Mock 360 view component - in a real app this would use a proper 360 view library
const CarView360 = ({ images }: { images: string[] }) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isDragging, setIsDragging] = useState(false);
  const [startX, setStartX] = useState(0);
  const containerRef = useRef<HTMLDivElement>(null);

  const nextImage = () => {
    setCurrentIndex((prev) => (prev + 1) % images.length);
  };

  const prevImage = () => {
    setCurrentIndex((prev) => (prev - 1 + images.length) % images.length);
  };

  const handleMouseDown = (e: React.MouseEvent) => {
    setIsDragging(true);
    setStartX(e.clientX);
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging) return;
    
    const deltaX = e.clientX - startX;
    if (deltaX > 50) {
      prevImage();
      setStartX(e.clientX);
    } else if (deltaX < -50) {
      nextImage();
      setStartX(e.clientX);
    }
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  return (
    <div className="relative bg-gray-900 rounded-lg overflow-hidden">
      <div className="absolute top-4 left-4 z-10 bg-white/10 backdrop-blur-sm px-3 py-1 rounded-full text-white text-sm">
        <RotateCw className="inline-block h-4 w-4 mr-1" />
        Drag to rotate
      </div>
      
      <div 
        ref={containerRef}
        className="relative h-[400px] cursor-grab active:cursor-grabbing"
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
      >
        {images.map((src, index) => (
          <div 
            key={index}
            className={`absolute inset-0 transition-opacity duration-300 ${
              index === currentIndex ? 'opacity-100' : 'opacity-0 pointer-events-none'
            }`}
          >
            <img 
              src={src} 
              alt={`360 view ${index}`} 
              className="w-full h-full object-contain"
            />
          </div>
        ))}
      </div>
      
      <div className="absolute bottom-4 left-0 right-0 flex justify-center space-x-2">
        <button 
          onClick={prevImage}
          className="bg-white/10 backdrop-blur-sm text-white p-2 rounded-full hover:bg-white/20 transition-colors"
        >
          <ChevronLeft className="h-5 w-5" />
        </button>
        <button 
          onClick={nextImage}
          className="bg-white/10 backdrop-blur-sm text-white p-2 rounded-full hover:bg-white/20 transition-colors"
        >
          <ChevronRight className="h-5 w-5" />
        </button>
      </div>
    </div>
  );
};

const CarDetailsPage = () => {
  const { t } = useLanguage();
  const { carId } = useParams<{ carId: string }>();
  const [searchParams] = useSearchParams();
  const view360Mode = searchParams.get('view') === '360';
  
  const [car, setCar] = useState<Car | null>(null);
  const [brandName, setBrandName] = useState('');
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedColor, setSelectedColor] = useState('');

  useEffect(() => {
    if (carId) {
      // In a real app, this would fetch from an API
      const carData = getCarById(carId);
      if (carData) {
        setCar(carData);
        setSelectedColor(carData.colors[0]);
        
        const brand = getBrandById(carData.brandId);
        if (brand) {
          setBrandName(brand.name);
        }
      }
      setIsLoading(false);
    }
  }, [carId]);

  const nextImage = () => {
    if (!car) return;
    setCurrentImageIndex((prev) => (prev + 1) % car.images.length);
  };

  const prevImage = () => {
    if (!car) return;
    setCurrentImageIndex((prev) => (prev - 1 + car.images.length) % car.images.length);
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-900"></div>
      </div>
    );
  }

  if (!car) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Car Not Found</h2>
          <p className="text-gray-600 mb-6">The car you're looking for doesn't exist or has been removed.</p>
          <Link 
            to="/brands" 
            className="inline-flex items-center text-blue-700 hover:text-blue-900"
          >
            <ChevronLeft className="h-5 w-5 mr-1" />
            Back to Brands
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-gray-50 min-h-screen">
      {/* Top Navigation */}
      <div className="bg-gradient-to-r from-blue-900 to-blue-700 text-white py-8">
        <div className="container mx-auto px-4">
          <Link to={`/brands/${car.brandId}`} className="inline-flex items-center text-white hover:underline">
            <ChevronLeft className="h-5 w-5 mr-1" />
            {`Back to ${brandName}`}
          </Link>
        </div>
      </div>

      {/* Car Details */}
      <div className="container mx-auto px-4 py-8">
        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Left Column - Images */}
            <div className="p-6">
              {view360Mode ? (
                <CarView360 images={car.images} />
              ) : (
                <div className="relative">
                  <div className="relative h-[400px] bg-gray-100 rounded-lg overflow-hidden">
                    <img 
                      src={car.images[currentImageIndex]} 
                      alt={car.model} 
                      className="w-full h-full object-contain"
                    />
                  </div>
                  
                  <div className="absolute top-1/2 left-4 transform -translate-y-1/2">
                    <button 
                      onClick={prevImage}
                      className="bg-white/70 text-gray-800 p-2 rounded-full hover:bg-white transition-colors"
                    >
                      <ChevronLeft className="h-5 w-5" />
                    </button>
                  </div>
                  
                  <div className="absolute top-1/2 right-4 transform -translate-y-1/2">
                    <button 
                      onClick={nextImage}
                      className="bg-white/70 text-gray-800 p-2 rounded-full hover:bg-white transition-colors"
                    >
                      <ChevronRight className="h-5 w-5" />
                    </button>
                  </div>
                </div>
              )}
              
              <div className="mt-4 flex justify-between">
                <div className="flex space-x-2">
                  {car.images.map((_, index) => (
                    <button
                      key={index}
                      onClick={() => setCurrentImageIndex(index)}
                      className={`w-3 h-3 rounded-full ${
                        currentImageIndex === index ? 'bg-blue-700' : 'bg-gray-300'
                      }`}
                    />
                  ))}
                </div>
                
                <Link 
                  to={view360Mode ? `/cars/${car.id}` : `/cars/${car.id}?view=360`}
                  className="text-blue-700 hover:text-blue-900 flex items-center text-sm"
                >
                  {view360Mode ? 'Standard View' : (
                    <>
                      <RotateCw className="h-4 w-4 mr-1" />
                      {t('viewIn360')}
                    </>
                  )}
                </Link>
              </div>
            </div>
            
            {/* Right Column - Details */}
            <div className="p-6">
              <div className="flex items-center mb-2">
                <span className="text-sm font-medium text-blue-700">{brandName}</span>
              </div>
              <h1 className="text-3xl font-bold text-gray-900 mb-2">{car.model} {car.year}</h1>
              <div className="flex items-center mb-6">
                <span className="text-2xl font-bold text-blue-700">${car.price.toLocaleString()}</span>
              </div>
              
              <p className="text-gray-600 mb-8">{car.description}</p>
              
              {/* Colors */}
              <div className="mb-8">
                <h3 className="text-lg font-semibold text-gray-900 mb-3">Colors</h3>
                <div className="flex space-x-3">
                  {car.colors.map((color) => (
                    <button
                      key={color}
                      onClick={() => setSelectedColor(color)}
                      className={`w-10 h-10 rounded-full border-2 flex items-center justify-center ${
                        selectedColor === color 
                          ? 'border-blue-700' 
                          : 'border-transparent hover:border-gray-300'
                      }`}
                    >
                      <span className="block w-8 h-8 rounded-full bg-gray-200" style={{ 
                        backgroundColor: color.toLowerCase().replace(/\s+/g, ''),
                      }}></span>
                    </button>
                  ))}
                </div>
                <p className="mt-2 text-sm text-gray-600">{selectedColor}</p>
              </div>
              
              {/* Quick Specs */}
              <div className="grid grid-cols-2 gap-4 mb-8">
                <div className="flex items-center">
                  <Calendar className="h-5 w-5 text-blue-700 mr-2" />
                  <div>
                    <p className="text-sm text-gray-500">Year</p>
                    <p className="font-medium">{car.year}</p>
                  </div>
                </div>
                
                <div className="flex items-center">
                  <Gauge className="h-5 w-5 text-blue-700 mr-2" />
                  <div>
                    <p className="text-sm text-gray-500">Horsepower</p>
                    <p className="font-medium">{car.specifications.horsepower} HP</p>
                  </div>
                </div>
                
                <div className="flex items-center">
                  <Fuel className="h-5 w-5 text-blue-700 mr-2" />
                  <div>
                    <p className="text-sm text-gray-500">Fuel Type</p>
                    <p className="font-medium">{car.fuelType}</p>
                  </div>
                </div>
                
                <div className="flex items-center">
                  <Settings className="h-5 w-5 text-blue-700 mr-2" />
                  <div>
                    <p className="text-sm text-gray-500">Transmission</p>
                    <p className="font-medium">{car.specifications.transmission}</p>
                  </div>
                </div>
              </div>
              
              {/* Action Buttons */}
              <div className="flex space-x-4">
                <button
                  className="flex-1 bg-blue-700 hover:bg-blue-800 text-white px-6 py-3 rounded-md font-medium transition-colors"
                >
                  Book Test Drive
                </button>
                <button
                  className="flex-1 border border-blue-700 text-blue-700 hover:bg-blue-50 px-6 py-3 rounded-md font-medium transition-colors"
                >
                  Contact Dealer
                </button>
              </div>
            </div>
          </div>
        </div>
        
        {/* Specifications */}
        <div className="mt-8 bg-white rounded-lg shadow-md overflow-hidden">
          <div className="border-b border-gray-200">
            <div className="flex overflow-x-auto">
              <button className="px-6 py-4 text-blue-700 border-b-2 border-blue-700 font-medium">
                {t('specifications')}
              </button>
              <button className="px-6 py-4 text-gray-500 hover:text-gray-700">
                {t('features')}
              </button>
            </div>
          </div>
          
          <div className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {/* Left Column */}
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Performance</h3>
                <dl className="space-y-4">
                  <div className="flex items-start">
                    <dt className="w-1/3 text-sm text-gray-600">{t('engine')}</dt>
                    <dd className="w-2/3 font-medium">{car.specifications.engine}</dd>
                  </div>
                  <div className="flex items-start">
                    <dt className="w-1/3 text-sm text-gray-600">Horsepower</dt>
                    <dd className="w-2/3 font-medium">{car.specifications.horsepower} HP</dd>
                  </div>
                  <div className="flex items-start">
                    <dt className="w-1/3 text-sm text-gray-600">Torque</dt>
                    <dd className="w-2/3 font-medium">{car.specifications.torque}</dd>
                  </div>
                  <div className="flex items-start">
                    <dt className="w-1/3 text-sm text-gray-600">{t('transmission')}</dt>
                    <dd className="w-2/3 font-medium">{car.specifications.transmission}</dd>
                  </div>
                  <div className="flex items-start">
                    <dt className="w-1/3 text-sm text-gray-600">Drivetrain</dt>
                    <dd className="w-2/3 font-medium">{car.specifications.drivetrain}</dd>
                  </div>
                </dl>
              </div>
              
              {/* Right Column */}
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Other Specifications</h3>
                <dl className="space-y-4">
                  <div className="flex items-start">
                    <dt className="w-1/3 text-sm text-gray-600">{t('fuelEfficiency')}</dt>
                    <dd className="w-2/3 font-medium">{car.specifications.fuelEfficiency}</dd>
                  </div>
                  <div className="flex items-start">
                    <dt className="w-1/3 text-sm text-gray-600">{t('acceleration')}</dt>
                    <dd className="w-2/3 font-medium">{car.specifications.acceleration}</dd>
                  </div>
                  <div className="flex items-start">
                    <dt className="w-1/3 text-sm text-gray-600">{t('topSpeed')}</dt>
                    <dd className="w-2/3 font-medium">{car.specifications.topSpeed}</dd>
                  </div>
                  <div className="flex items-start">
                    <dt className="w-1/3 text-sm text-gray-600">Seating</dt>
                    <dd className="w-2/3 font-medium">{car.seatingCapacity} passengers</dd>
                  </div>
                  <div className="flex items-start">
                    <dt className="w-1/3 text-sm text-gray-600">Body Type</dt>
                    <dd className="w-2/3 font-medium">{car.bodyType}</dd>
                  </div>
                </dl>
              </div>
            </div>
            
            {/* Features */}
            <div className="mt-8">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Key Features</h3>
              <ul className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {car.features.map((feature, index) => (
                  <li key={index} className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CarDetailsPage;