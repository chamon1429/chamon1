import { useState, useEffect } from 'react';
import { Link, useParams } from 'react-router-dom';
import { useLanguage } from '../contexts/LanguageContext';
import { getAllBrands, getBrandById, Brand } from '../data/brands';
import { getCarsByBrand, Car } from '../data/cars';
import { ChevronLeft } from 'lucide-react';

const BrandsPage = () => {
  const { t } = useLanguage();
  const { brandId } = useParams<{ brandId: string }>();
  
  const [brands, setBrands] = useState<Brand[]>([]);
  const [cars, setCars] = useState<Car[]>([]);
  const [selectedBrand, setSelectedBrand] = useState<Brand | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // In a real app, this would fetch from an API
    const allBrands = getAllBrands();
    setBrands(allBrands);
    
    if (brandId) {
      const brand = getBrandById(brandId);
      if (brand) {
        setSelectedBrand(brand);
        const brandCars = getCarsByBrand(brandId);
        setCars(brandCars);
      }
    }
    
    setIsLoading(false);
  }, [brandId]);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-900"></div>
      </div>
    );
  }

  // Showing specific brand and its cars
  if (selectedBrand) {
    return (
      <div className="bg-gray-50 min-h-screen">
        {/* Brand Header */}
        <div className="bg-gradient-to-r from-blue-900 to-blue-700 text-white py-16">
          <div className="container mx-auto px-4">
            <Link to="/brands" className="inline-flex items-center text-white mb-6 hover:underline">
              <ChevronLeft className="h-5 w-5 mr-1" />
              {t('allBrands')}
            </Link>
            <h1 className="text-4xl font-bold mb-4">{selectedBrand.name}</h1>
            <p className="max-w-2xl text-blue-100">{selectedBrand.description}</p>
            <div className="flex items-center mt-6 text-sm text-blue-100">
              <span className="mr-6">
                <strong className="text-white">Country:</strong> {selectedBrand.country}
              </span>
              <span>
                <strong className="text-white">Founded:</strong> {selectedBrand.foundedYear}
              </span>
            </div>
          </div>
        </div>

        {/* Car Models */}
        <div className="container mx-auto px-4 py-12">
          <h2 className="text-2xl font-bold text-gray-900 mb-8">{t('popularModels')}</h2>
          
          {cars.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {cars.map((car) => (
                <div key={car.id} className="bg-white rounded-lg shadow-md overflow-hidden group">
                  <div className="h-48 overflow-hidden">
                    <img 
                      src={car.images[0]} 
                      alt={car.model} 
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                  </div>
                  <div className="p-6">
                    <h3 className="text-xl font-bold text-gray-900 mb-2">{car.model}</h3>
                    <p className="text-blue-700 font-semibold mb-4">${car.price.toLocaleString()}</p>
                    <div className="flex flex-wrap gap-4 mb-4">
                      <div className="flex items-center text-sm text-gray-600">
                        <span>{car.specifications.engine}</span>
                      </div>
                      <div className="flex items-center text-sm text-gray-600">
                        <span>{car.specifications.horsepower} HP</span>
                      </div>
                    </div>
                    <div className="flex space-x-3">
                      <Link 
                        to={`/cars/${car.id}`}
                        className="flex-1 inline-block bg-blue-700 hover:bg-blue-800 text-white px-4 py-2 rounded-md font-medium transition-colors text-center"
                      >
                        {t('viewDetails')}
                      </Link>
                      <Link 
                        to={`/cars/${car.id}?view=360`}
                        className="flex-1 inline-block border border-blue-700 text-blue-700 hover:bg-blue-50 px-4 py-2 rounded-md font-medium transition-colors text-center"
                      >
                        {t('viewIn360')}
                      </Link>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8">
              <p className="text-gray-600">No cars available for this brand at the moment.</p>
            </div>
          )}
        </div>
      </div>
    );
  }

  // Show all brands
  return (
    <div className="bg-gray-50 min-h-screen">
      {/* Brands Header */}
      <div className="bg-gradient-to-r from-blue-900 to-blue-700 text-white py-16">
        <div className="container mx-auto px-4">
          <h1 className="text-4xl font-bold mb-4">{t('allBrands')}</h1>
          <p className="max-w-2xl text-blue-100">
            Explore our comprehensive selection of automotive brands, each with their own unique history, style, and performance characteristics.
          </p>
        </div>
      </div>

      {/* Brands Grid */}
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
          {brands.map((brand) => (
            <Link 
              key={brand.id}
              to={`/brands/${brand.id}`}
              className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow flex flex-col items-center text-center"
            >
              <div className="h-24 w-24 flex items-center justify-center mb-4 bg-gray-100 rounded-full">
                {/* Use brand logo or placeholder */}
                <span className="text-3xl font-bold text-blue-900">{brand.name.charAt(0)}</span>
              </div>
              <h2 className="text-xl font-bold text-gray-900 mb-2">{brand.name}</h2>
              <p className="text-gray-600 mb-4 line-clamp-2">{brand.description}</p>
              <div className="mt-auto pt-4 border-t border-gray-100 w-full flex justify-between text-sm text-gray-500">
                <span>{brand.country}</span>
                <span>Est. {brand.foundedYear}</span>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
};

export default BrandsPage;