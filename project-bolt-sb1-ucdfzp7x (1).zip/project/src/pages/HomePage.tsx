import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { ChevronRight, ArrowRight, Phone, MessageCircle, Mail } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import { getAllBrands, Brand } from '../data/brands';
import { getAllCars, Car } from '../data/cars';

const HomePage = () => {
  const { t } = useLanguage();
  const [featuredCars, setFeaturedCars] = useState<Car[]>([]);
  const [topBrands, setTopBrands] = useState<Brand[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // In a real app, this would fetch from an API
    // For the demo, we'll use our local data
    const cars = getAllCars();
    const brands = getAllBrands();
    
    // Get 4 featured cars
    const featured = [...cars].sort(() => 0.5 - Math.random()).slice(0, 4);
    setFeaturedCars(featured);
    
    // Get 6 top brands
    const top = [...brands].sort(() => 0.5 - Math.random()).slice(0, 6);
    setTopBrands(top);
    
    setIsLoading(false);
  }, []);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-900"></div>
      </div>
    );
  }

  return (
    <div className="bg-gray-50">
      {/* Hero Section */}
      <section className="relative h-[80vh] bg-black">
        <div 
          className="absolute inset-0 bg-cover bg-center bg-no-repeat"
          style={{ 
            backgroundImage: 'url(https://images.pexels.com/photos/3422964/pexels-photo-3422964.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2)', 
            opacity: 0.7 
          }}
        ></div>
        <div className="absolute inset-0 bg-gradient-to-r from-black/70 to-transparent"></div>
        <div className="relative container mx-auto px-4 h-full flex items-center">
          <div className="max-w-xl text-white">
            <h1 className="text-5xl md:text-6xl font-bold mb-4">
              {t('welcomeHeading')}
            </h1>
            <p className="text-xl mb-8">
              {t('welcomeSubheading')}
            </p>
            <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4">
              <Link 
                to="/brands" 
                className="bg-blue-700 hover:bg-blue-800 text-white px-8 py-3 rounded-md font-medium transition-colors inline-flex items-center"
              >
                {t('exploreVehicles')} <ChevronRight className="ml-2 h-5 w-5" />
              </Link>
              <Link 
                to="/contact" 
                className="bg-white hover:bg-gray-100 text-blue-900 px-8 py-3 rounded-md font-medium transition-colors"
              >
                {t('bookTestDrive')}
              </Link>
            </div>
          </div>
        </div>
        <div className="absolute bottom-0 left-0 right-0">
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 100" className="fill-gray-50">
            <path d="M0,0 L1440,0 L1440,100 C1200,33.3 960,0 720,0 C480,0 240,33.3 0,100 L0,0 Z" />
          </svg>
        </div>
      </section>

      {/* Featured Vehicles */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center mb-10">
            <h2 className="text-3xl font-bold text-gray-900">{t('featuredVehicles')}</h2>
            <Link to="/brands" className="text-blue-700 hover:text-blue-900 flex items-center">
              {t('viewAll')} <ArrowRight className="ml-1 h-4 w-4" />
            </Link>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {featuredCars.map((car) => (
              <div key={car.id} className="bg-white rounded-lg shadow-md overflow-hidden group">
                <div className="h-48 overflow-hidden">
                  <img 
                    src={car.images[0]} 
                    alt={car.model} 
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-bold text-gray-900 mb-2">{car.model}</h3>
                  <p className="text-blue-700 font-semibold mb-4">${car.price.toLocaleString()}</p>
                  <div className="flex flex-wrap gap-4 mb-4">
                    <div className="flex items-center text-sm text-gray-600">
                      <span>{car.specifications.engine}</span>
                    </div>
                    <div className="flex items-center text-sm text-gray-600">
                      <span>{car.specifications.horsepower} HP</span>
                    </div>
                  </div>
                  <Link 
                    to={`/cars/${car.id}`}
                    className="mt-2 inline-block bg-blue-700 hover:bg-blue-800 text-white px-6 py-2 rounded-md font-medium transition-colors"
                  >
                    {t('viewDetails')}
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Top Brands */}
      <section className="py-16 bg-gray-100">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center mb-10">
            <h2 className="text-3xl font-bold text-gray-900">{t('topBrands')}</h2>
            <Link to="/brands" className="text-blue-700 hover:text-blue-900 flex items-center">
              {t('viewAll')} <ArrowRight className="ml-1 h-4 w-4" />
            </Link>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6">
            {topBrands.map((brand) => (
              <Link 
                key={brand.id} 
                to={`/brands/${brand.id}`}
                className="flex flex-col items-center justify-center bg-white p-6 rounded-lg shadow-sm hover:shadow-md transition-shadow"
              >
                <div className="h-24 w-24 flex items-center justify-center mb-4">
                  {/* Use brand logo or placeholder */}
                  <span className="text-3xl font-bold text-blue-900">{brand.name.charAt(0)}</span>
                </div>
                <h3 className="text-lg font-semibold text-gray-900">{brand.name}</h3>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Virtual Tour */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="flex flex-col lg:flex-row items-center bg-gradient-to-r from-blue-900 to-blue-700 rounded-2xl overflow-hidden shadow-xl">
            <div className="lg:w-1/2 p-8 lg:p-12">
              <h2 className="text-3xl font-bold text-white mb-4">Virtual 360° Tour</h2>
              <p className="text-blue-100 mb-6">
                Experience our vehicles in stunning 360° detail. Explore interiors, exteriors, and every feature without leaving your home.
              </p>
              <Link 
                to="/brands" 
                className="inline-block bg-white hover:bg-gray-100 text-blue-900 px-8 py-3 rounded-md font-medium transition-colors"
              >
                Explore 360° Views
              </Link>
            </div>
            <div className="lg:w-1/2">
              <img 
                src="https://images.pexels.com/photos/3802510/pexels-photo-3802510.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" 
                alt="Virtual Tour" 
                className="w-full h-80 lg:h-full object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      {/* 24/7 Support */}
      <section className="py-16 bg-gray-100">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-3xl mx-auto mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">24/7 Customer Support</h2>
            <p className="text-gray-600">
              Our team is always available to assist you with any questions or concerns. Reach out to us anytime, day or night.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white p-8 rounded-lg shadow-md text-center">
              <div className="bg-blue-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-6">
                <Phone className="h-8 w-8 text-blue-700" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">Call Us</h3>
              <p className="text-gray-600 mb-4">Speak directly with our support team</p>
              <a href="tel:1-800-LUXE-AUTO" className="text-blue-700 font-medium">1-800-LUXE-AUTO</a>
            </div>
            
            <div className="bg-white p-8 rounded-lg shadow-md text-center">
              <div className="bg-blue-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-6">
                <MessageCircle className="h-8 w-8 text-blue-700" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">Live Chat</h3>
              <p className="text-gray-600 mb-4">Chat with our support team instantly</p>
              <button className="text-blue-700 font-medium">Start Chat Now</button>
            </div>
            
            <div className="bg-white p-8 rounded-lg shadow-md text-center">
              <div className="bg-blue-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-6">
                <Mail className="h-8 w-8 text-blue-700" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">Email Us</h3>
              <p className="text-gray-600 mb-4">Send us your questions anytime</p>
              <a href="mailto:support@luxeauto.com" className="text-blue-700 font-medium">support@luxeauto.com</a>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default HomePage;