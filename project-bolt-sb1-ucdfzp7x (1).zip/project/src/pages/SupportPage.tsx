import { useState } from 'react';
import { Link } from 'react-router-dom';
import { useLanguage } from '../contexts/LanguageContext';
import { MessageCircle, Phone, Mail, ChevronDown, ChevronUp } from 'lucide-react';

// FAQ Item Component
interface FAQItemProps {
  question: string;
  answer: string;
}

const FAQItem: React.FC<FAQItemProps> = ({ question, answer }) => {
  const [isOpen, setIsOpen] = useState(false);
  
  return (
    <div className="border-b border-gray-200 last:border-b-0">
      <button
        className="flex items-center justify-between w-full py-4 text-left"
        onClick={() => setIsOpen(!isOpen)}
      >
        <span className="font-medium text-gray-900">{question}</span>
        {isOpen ? (
          <ChevronUp className="h-5 w-5 text-gray-500" />
        ) : (
          <ChevronDown className="h-5 w-5 text-gray-500" />
        )}
      </button>
      
      {isOpen && (
        <div className="pb-4 pr-12 text-gray-600">
          <p>{answer}</p>
        </div>
      )}
    </div>
  );
};

// Mock Live Chat Component
const LiveChatSupport = () => {
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [message, setMessage] = useState('');
  const [messages, setMessages] = useState<{text: string; isUser: boolean}[]>([
    { text: 'Hello! How can I help you today?', isUser: false }
  ]);
  
  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!message.trim()) return;
    
    // Add user message
    setMessages(prev => [...prev, { text: message, isUser: true }]);
    setMessage('');
    
    // Simulate response after a short delay
    setTimeout(() => {
      setMessages(prev => [
        ...prev, 
        { 
          text: 'Thank you for your message. One of our agents will be with you shortly.', 
          isUser: false 
        }
      ]);
    }, 1000);
  };
  
  if (!isChatOpen) {
    return (
      <button
        onClick={() => setIsChatOpen(true)}
        className="w-full bg-blue-700 hover:bg-blue-800 text-white px-6 py-3 rounded-md font-medium transition-colors flex items-center justify-center"
      >
        <MessageCircle className="h-5 w-5 mr-2" />
        Start Live Chat
      </button>
    );
  }
  
  return (
    <div className="bg-white rounded-lg shadow-md border border-gray-200 overflow-hidden">
      <div className="bg-blue-700 text-white p-4 flex items-center justify-between">
        <h3 className="font-medium">Live Chat Support</h3>
        <button 
          onClick={() => setIsChatOpen(false)}
          className="text-white/80 hover:text-white"
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
            <path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd" />
          </svg>
        </button>
      </div>
      
      <div className="h-64 p-4 overflow-y-auto">
        {messages.map((msg, index) => (
          <div
            key={index}
            className={`mb-4 ${msg.isUser ? 'text-right' : ''}`}
          >
            <div
              className={`inline-block px-4 py-2 rounded-lg ${
                msg.isUser 
                  ? 'bg-blue-700 text-white rounded-br-none' 
                  : 'bg-gray-100 text-gray-800 rounded-bl-none'
              }`}
            >
              {msg.text}
            </div>
          </div>
        ))}
      </div>
      
      <form onSubmit={handleSendMessage} className="border-t border-gray-200 p-4 flex">
        <input
          type="text"
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          placeholder="Type your message..."
          className="flex-1 px-3 py-2 border border-gray-300 rounded-l-md focus:outline-none focus:ring-blue-500 focus:border-blue-500"
        />
        <button
          type="submit"
          className="bg-blue-700 text-white px-4 py-2 rounded-r-md hover:bg-blue-800 transition-colors"
        >
          Send
        </button>
      </form>
    </div>
  );
};

const SupportPage = () => {
  const { t } = useLanguage();
  
  // FAQ data
  const faqs = [
    {
      question: 'How do I schedule a test drive?',
      answer: 'You can schedule a test drive by visiting our contact page, calling our sales department, or using the "Book Test Drive" button on any vehicle detail page. We\'ll confirm your appointment and have the vehicle ready when you arrive.'
    },
    {
      question: 'What documents do I need to purchase a vehicle?',
      answer: 'To purchase a vehicle, you\'ll need a valid driver\'s license, proof of insurance, and proof of income if financing. If you\'re trading in a vehicle, bring your title, registration, and all keys.'
    },
    {
      question: 'How does the financing process work?',
      answer: 'Our financing process is simple. You can start by filling out a pre-approval form online. Our finance team will review your application and present you with options tailored to your situation. We work with multiple lenders to ensure you get the best rates possible.'
    },
    {
      question: 'Do you offer warranties on your vehicles?',
      answer: 'Yes, all of our new vehicles come with the manufacturer\'s warranty. We also offer extended warranty options for both new and pre-owned vehicles. Our sales team can provide details specific to the vehicle you\'re interested in.'
    },
    {
      question: 'How often should I service my vehicle?',
      answer: 'We recommend following the manufacturer\'s maintenance schedule, which can be found in your owner\'s manual. Typically, this includes service every 5,000-7,500 miles. Regular maintenance ensures your vehicle performs optimally and helps maintain its value.'
    },
    {
      question: 'Can I order a custom vehicle with specific features?',
      answer: 'Absolutely! We can help you order a custom vehicle directly from the manufacturer with your preferred specifications, colors, and features. The delivery time varies by brand and model, but we\'ll keep you updated throughout the process.'
    }
  ];

  return (
    <div className="bg-gray-50 min-h-screen">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-900 to-blue-700 text-white py-16">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl font-bold mb-4">{t('supportHeading')}</h1>
          <p className="max-w-2xl mx-auto text-blue-100">{t('supportSubheading')}</p>
        </div>
      </div>

      {/* Support Options */}
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
          {/* Phone Support */}
          <div className="bg-white rounded-lg shadow-md p-6 text-center">
            <div className="bg-blue-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-6">
              <Phone className="h-8 w-8 text-blue-700" />
            </div>
            <h3 className="text-xl font-bold text-gray-900 mb-2">Phone Support</h3>
            <p className="text-gray-600 mb-6">
              Speak directly with our support team 24/7 for immediate assistance.
            </p>
            <a 
              href="tel:1-800-LUXE-AUTO" 
              className="block w-full bg-white border border-blue-700 text-blue-700 hover:bg-blue-50 px-6 py-3 rounded-md font-medium transition-colors"
            >
              1-800-LUXE-AUTO
            </a>
          </div>
          
          {/* Live Chat */}
          <div className="bg-white rounded-lg shadow-md p-6 text-center">
            <div className="bg-blue-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-6">
              <MessageCircle className="h-8 w-8 text-blue-700" />
            </div>
            <h3 className="text-xl font-bold text-gray-900 mb-2">{t('liveChatSupport')}</h3>
            <p className="text-gray-600 mb-6">
              Chat with our support agents online for quick and convenient help.
            </p>
            <LiveChatSupport />
          </div>
          
          {/* Email Support */}
          <div className="bg-white rounded-lg shadow-md p-6 text-center">
            <div className="bg-blue-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-6">
              <Mail className="h-8 w-8 text-blue-700" />
            </div>
            <h3 className="text-xl font-bold text-gray-900 mb-2">Email Support</h3>
            <p className="text-gray-600 mb-6">
              Send us your questions and we\'ll respond as soon as possible.
            </p>
            <a 
              href="mailto:support@luxeauto.com" 
              className="block w-full bg-white border border-blue-700 text-blue-700 hover:bg-blue-50 px-6 py-3 rounded-md font-medium transition-colors"
            >
              support@luxeauto.com
            </a>
          </div>
        </div>
        
        {/* FAQ Section */}
        <div className="max-w-3xl mx-auto">
          <h2 className="text-3xl font-bold text-center text-gray-900 mb-8">{t('faq')}</h2>
          
          <div className="bg-white rounded-lg shadow-md overflow-hidden">
            {faqs.map((faq, index) => (
              <FAQItem key={index} question={faq.question} answer={faq.answer} />
            ))}
          </div>
          
          <div className="text-center mt-8">
            <p className="text-gray-600 mb-4">
              Still have questions? We\'re here to help.
            </p>
            <Link 
              to="/contact" 
              className="inline-block bg-blue-700 hover:bg-blue-800 text-white px-6 py-3 rounded-md font-medium transition-colors"
            >
              {t('contactUs')}
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SupportPage;